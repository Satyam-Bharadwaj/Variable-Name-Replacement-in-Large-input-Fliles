#include<stdio.h>
int main()
{
int p,parent[10],y;

parent[0] = 5;
p=3;
printf(y);
return 0;
}
