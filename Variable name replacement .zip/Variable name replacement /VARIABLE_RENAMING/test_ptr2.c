#include <stdio.h>
int main()
{
int p,parent[10],y;
int *pars=p;
parent[0] = 5;
p=3;
printf(y);
printf("%p",&pars);
}
