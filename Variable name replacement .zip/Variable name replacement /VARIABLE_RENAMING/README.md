INSTRUCTIONS:
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
1. First make sure you have a file "filename" that contains a C/C++ program.
2. Compile line_store_final.c => Ex. gcc line_store_final.c											+
3. The newly created executable takes a filename as parameter, since it operates on a file => Ex. ./a.out "filename"				+
4. After giving the necessary inputs, look at the newly generated "symbol_table.txt" and "final.txt" which gives the necessary outputs you need.+
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
